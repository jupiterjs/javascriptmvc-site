@function can.EJS.tags.comment <%# CODE %>
@parent can.EJS.tags 4


@signature `<%# CODE %>`

Used for comments.  This does nothing.
     
         <%# 'hello world' %>