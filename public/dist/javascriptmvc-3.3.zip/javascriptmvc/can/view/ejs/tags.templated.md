@function can.EJS.tags.templated <%% CODE %>
@parent can.EJS.tags 3

@signature `<%% CODE %>` 

 Writes <% CODE %> to the result of the template.  This is useful for generators.
     
         <%%= 'hello world' %>