@page can.util can.util
@parent canjs

Utility methods supported by CanJS