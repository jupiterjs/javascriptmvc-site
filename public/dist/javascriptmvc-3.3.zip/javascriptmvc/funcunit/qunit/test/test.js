module("qunit")

test("something",function(){
	ok(true,"it's ok")
})
test("sanity",function(){
	equal(1+1,2,"one plus one equals two")
})