[![CanJS](http://canjs.us/images/canjs_logo_yellow_small.png)](http://canjs.us/)
 
[![Build Status](https://travis-ci.org/bitovi/canjs.png?branch=master)](https://travis-ci.org/bitovi/canjs)

CanJS is a MIT-licensed, client-side, JavaScript framework that makes building 
rich web applications easy. Use it because it’s:

- Smaller 
- Faster 
- Safer 
- Easier 
- Library-er

Go to [http://canjs.us/](http://canjs.us/) for docs, downloads, tests, demos, and more.  Join us on the Freenode IRC Channel #canjs.
