steal('can/util/jquery', function(can) {
	return can;
});