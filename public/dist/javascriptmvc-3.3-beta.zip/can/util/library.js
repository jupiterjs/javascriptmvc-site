// This is mainly used for the AMD build
steal('can/util/jquery', function(can) {
	return can;
});