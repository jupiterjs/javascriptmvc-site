//js jmvcdoc/scripts/docs.js
_args = ['documentjs/jmvcdoc/jmvcdoc.html']
load("documentjs/documentjs.js");