steal("./fixture/fixture_test.js",
	"./object/object_test.js",
	"./string/string_test.js")